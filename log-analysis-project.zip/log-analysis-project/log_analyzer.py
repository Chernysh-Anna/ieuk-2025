
"""
Web Traffic Log Analysis Tool :
Analyzes web server logs to identify bot traffic and  load patterns
"""

import re
import csv
from collections import defaultdict, Counter
from datetime import datetime
import argparse
import sys
from typing import Dict, List
import statistics


class LogAnalyzer:
    """Analyzes web server logs to detect bot traffic and performance issues"""

    def __init__(self, log_file_path: str):
        self.log_file_path = log_file_path
        self.log_entries = []
        self.suspicious_ips = set()
        self.bot_indicators = []

        # Common bot user agents patterns
        self.bot_user_agents = [
            r'bot', r'crawler', r'spider', r'scraper', r'curl', r'wget',
            r'python-requests', r'Go-http-client', r'Apache-HttpClient',
            r'Java/', r'libwww', r'lwp-', r'WinHttp', r'HTTPie'
        ]

        # Suspicious request patterns
        self.suspicious_patterns = [
            r'\.php$', r'\.asp$', r'\.jsp$', r'wp-admin', r'admin',
            r'\.env', r'config\.', r'backup', r'\.sql', r'\.log'
        ]

    def parse_log_line(self, line: str) -> Dict:
        "Parse a log line into structured data"
        pattern = r'(\d+\.\d+\.\d+\.\d+) - (\w+) - \[([^\]]+)\] "(\w+) ([^"]*) HTTP/[^"]*" (\d+) (\d+) "([^"]*)" "([^"]*)" (\d+)'
        match = re.match(pattern, line.strip())
        if not match:
            return None

        return {
            'ip': match.group(1),
            'country': match.group(2),
            'timestamp': match.group(3),
            'method': match.group(4),
            'url': match.group(5),
            'status': int(match.group(6)),
            'size': int(match.group(7)),
            'referer': match.group(8),
            'user_agent': match.group(9),
            'response_time': int(match.group(10))
        }

    def load_logs(self) -> None:
        "Load and parse log file"
        try:
            with open(self.log_file_path, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    parsed = self.parse_log_line(line)
                    if parsed:
                        self.log_entries.append(parsed)
                    elif line.strip():  # Skip empty lines
                        print(f"Warning: Could not parse line {line_num}")
        except FileNotFoundError:
            print(f"Error: Log file '{self.log_file_path}' not found")
            sys.exit(1)

    def analyze_ip_patterns(self) -> Dict:
        "Analyze IP address patterns for bot detection"
        ip_stats = defaultdict(lambda: {
            'requests': 0,
            'unique_urls': set(),
            'user_agents': set(),
            'status_codes': [],
            'request_intervals': [],
            'countries': set()
        })

        # Group by IP and collect statistics
        for entry in self.log_entries:
            ip = entry['ip']
            ip_stats[ip]['requests'] += 1
            ip_stats[ip]['unique_urls'].add(entry['url'])
            ip_stats[ip]['user_agents'].add(entry['user_agent'])
            ip_stats[ip]['status_codes'].append(entry['status'])
            ip_stats[ip]['countries'].add(entry['country'])

        # Calculate request intervals for each IP
        ip_timestamps = defaultdict(list)
        for entry in self.log_entries:
            timestamp = datetime.strptime(entry['timestamp'], '%d/%m/%Y:%H:%M:%S')
            ip_timestamps[entry['ip']].append(timestamp)

        for ip, timestamps in ip_timestamps.items():
            if len(timestamps) > 1:
                timestamps.sort()
                intervals = [(timestamps[i + 1] - timestamps[i]).total_seconds()
                             for i in range(len(timestamps) - 1)]
                ip_stats[ip]['request_intervals'] = intervals

        return dict(ip_stats)

    def detect_bot_behavior(self, ip_stats: Dict) -> List[Dict]:
        "Detect potential bot behavior based on various indicators"
        bot_candidates = []

        for ip, stats in ip_stats.items():
            bot_score = 0
            indicators = []
            # High request volume
            if stats['requests'] > 100:
                bot_score += 3
                indicators.append(f"High request volume: {stats['requests']}")
            elif stats['requests'] > 50:
                bot_score += 2
                indicators.append(f"Moderate request volume: {stats['requests']}")

            # same pages repeatedly
            url_diversity = len(stats['unique_urls']) / stats['requests']
            if url_diversity < 0.3:
                bot_score += 2
                indicators.append(f"Low URL diversity: {url_diversity:.2f}")

            # Suspicious user agents
            for ua in stats['user_agents']:
                for pattern in self.bot_user_agents:
                    if re.search(pattern, ua, re.IGNORECASE):
                        bot_score += 4
                        indicators.append(f"Bot user agent: {ua}")
                        break

            # Regular request intervals
            if stats['request_intervals']:
                if len(stats['request_intervals']) > 10:
                    interval_std = statistics.stdev(stats['request_intervals'])
                    if interval_std < 2.0:  # Very regular intervals
                        bot_score += 2
                        indicators.append(f"Regular intervals: {interval_std:.2f}s std dev")

            # High error rate
            error_rate = sum(1 for code in stats['status_codes'] if code >= 400) / len(stats['status_codes'])
            if error_rate > 0.5:
                bot_score += 1
                indicators.append(f"High error rate: {error_rate:.2f}")

            # Single user / no browser diversity
            if len(stats['user_agents']) == 1 and stats['requests'] > 20:
                bot_score += 1
                indicators.append("Single user agent")

            # Suspicious URL patterns
            for url in stats['unique_urls']:
                for pattern in self.suspicious_patterns:
                    if re.search(pattern, url, re.IGNORECASE):
                        bot_score += 2
                        indicators.append(f"Suspicious URL: {url}")
                        break

            if bot_score >= 4:  # Threshold for bot classification
                bot_candidates.append({
                    'ip': ip,
                    'score': bot_score,
                    'indicators': indicators,
                    'stats': stats
                })

        return sorted(bot_candidates, key=lambda x: x['score'], reverse=True)

    def analyze_performance(self) -> Dict:
        "Analyze server performance metrics"
        response_times = [entry['response_time'] for entry in self.log_entries]
        status_codes = [entry['status'] for entry in self.log_entries]

        # URL popularity
        url_hits = Counter(entry['url'] for entry in self.log_entries)

        # Peak traffic analysis
        hourly_traffic = defaultdict(int)
        for entry in self.log_entries:
            timestamp = datetime.strptime(entry['timestamp'], '%d/%m/%Y:%H:%M:%S')
            hour_key = timestamp.strftime('%H:00')
            hourly_traffic[hour_key] += 1

        return {
            'avg_response_time': statistics.mean(response_times),
            'max_response_time': max(response_times),
            'total_requests': len(self.log_entries),
            'error_rate': sum(1 for code in status_codes if code >= 400) / len(status_codes),
            'top10_urls': url_hits.most_common(10),
            'peak_hours': sorted(hourly_traffic.items(), key=lambda x: x[1], reverse=True)[:5]
        }

    def generate_report(self) -> str:
        "Generate comprehensive analysis report"
        ip_stats = self.analyze_ip_patterns()
        bot_candidates = self.detect_bot_behavior(ip_stats)
        performance = self.analyze_performance()

        report = []
        report.append("=== WEB TRAFFIC ANALYSIS REPORT ===\n")

        # Performance Summary
        report.append("PERFORMANCE METRICS:")
        report.append(f"Total Requests: {performance['total_requests']:,}")
        report.append(f"Average Response Time: {performance['avg_response_time']:.0f}ms")
        report.append(f"Error Rate: {performance['error_rate']:.2%}")
        report.append("")

        # Top 10 URLs
        report.append("TOP REQUESTED PAGES:")
        for url, count in performance['top10_urls']:
            report.append(f"  {url}: {count} requests")
        report.append("")

        # Results for bot detection
        report.append("SUSPECTED BOT TRAFFIC:")
        if bot_candidates:
            report.append(f"Found {len(bot_candidates)} suspicious IP addresses")
            for bot in bot_candidates[:3]:  # Top 3 suspects
                report.append(f"\nIP: {bot['ip']} (Score: {bot['score']})")
                report.append(f"  Requests: {bot['stats']['requests']}")
                report.append(f"  Countries: {', '.join(bot['stats']['countries'])}")
                report.append("  Indicators:")
                for indicator in bot['indicators']:
                    report.append(f"    - {indicator}")
        else:
            report.append("No clear bot patterns detected in sample data")
        report.append("")

        # Peak traffic hours
        report.append("PEAK TRAFFIC HOURS:")
        for hour, count in performance['peak_hours']:
            report.append(f"  {hour}: {count} requests")

        return "\n".join(report)

    def export_suspicious_ips(self, filename: str) -> None:
        "Export suspicious IPs to CSV for blocking"
        ip_stats = self.analyze_ip_patterns()
        bot_candidates = self.detect_bot_behavior(ip_stats)

        with open(filename, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['IP', 'Score', 'Requests', 'Countries', 'Primary_Indicator'])

            for bot in bot_candidates:
                writer.writerow([
                    bot['ip'],
                    bot['score'],
                    bot['stats']['requests'],
                    ', '.join(bot['stats']['countries']),
                    bot['indicators'][0] if bot['indicators'] else ''
                ])


def main():
    parser = argparse.ArgumentParser(description='Analyze web server logs for bot detection')
    parser.add_argument('log_file', help='Path to the log file')
    parser.add_argument('--export-csv', help='Export suspicious IPs to CSV file')
    parser.add_argument('--report-only', action='store_true', help='Only generate report, no CSV export')

    args = parser.parse_args()

    analyzer = LogAnalyzer(args.log_file)
    print("Loading and parsing log file...")
    analyzer.load_logs()

    print(f"Processed {len(analyzer.log_entries)} log entries")
    print("\nGenerating analysis report...")

    report = analyzer.generate_report()
    print(report)

    # Export suspicious IPs if requested
    if args.export_csv:
        analyzer.export_suspicious_ips(args.export_csv)
        print(f"\nSuspicious IPs exported to {args.export_csv}")
    elif not args.report_only:
        analyzer.export_suspicious_ips('suspicious_ips.csv')
        print("\nSuspicious IPs exported to suspicious_ips.csv")


if __name__ == "__main__":
    main()