"""
Unit tests for the log analyzer
"""

import unittest
import tempfile
import os
from log_analyzer import LogAnalyzer


class TestLogAnalyzer(unittest.TestCase):

    def setUp(self):
        """Set up test fixtures"""
        self.sample_log_data = """100.34.17.233 - NO - [01/07/2025:06:00:02] "GET /news/grammy-nominations-2024 HTTP/1.1" 302 1234 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" 269
        173.80.18.254 - NO - [01/07/2025:06:00:04] "POST / HTTP/1.1" 200 1234 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" 124
        10.3.0.48 - SE - [01/07/2025:06:00:06] "GET /podcasts/behind-the-beat HTTP/1.1" 200 1234 "-" "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1" 284
        192.168.1.1 - US - [01/07/2025:06:00:08] "GET /admin HTTP/1.1" 404 1234 "-" "Python-urllib/3.8" 100
        192.168.1.1 - US - [01/07/2025:06:00:09] "GET /.env HTTP/1.1" 404 1234 "-" "Python-urllib/3.8" 120
        192.168.1.1 - US - [01/07/2025:06:00:10] "GET /config.php HTTP/1.1" 500 1234 "-" "Python-urllib/3.8" 110
        192.168.1.1 - US - [01/07/2025:06:00:11] "GET /wp-admin HTTP/1.1" 403 1234 "-" "Python-urllib/3.8" 115
        """

        # Create temporary log file
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
        self.temp_file.write(self.sample_log_data)
        self.temp_file.close()

        self.analyzer = LogAnalyzer(self.temp_file.name)

    def tearDown(self):
        """Clean up test fixtures"""
        os.unlink(self.temp_file.name)

    def test_parse_log_line(self):
        """Test log line parsing"""
        line = '100.34.17.233 - NO - [01/07/2025:06:00:02] "GET /news/grammy-nominations-2024 HTTP/1.1" 302 1234 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" 269'
        parsed = self.analyzer.parse_log_line(line)

        self.assertEqual(parsed['ip'], '100.34.17.233')
        self.assertEqual(parsed['country'], 'NO')
        self.assertEqual(parsed['method'], 'GET')
        self.assertEqual(parsed['url'], '/news/grammy-nominations-2024')
        self.assertEqual(parsed['status'], 302)
        self.assertEqual(parsed['response_time'], 269)

    def test_load_logs(self):
        """Test log loading functionality"""
        self.analyzer.load_logs()
        self.assertEqual(len(self.analyzer.log_entries), 7)

        # Check first entry
        first_entry = self.analyzer.log_entries[0]
        self.assertEqual(first_entry['ip'], '100.34.17.233')
        self.assertEqual(first_entry['country'], 'NO')

    def test_analyze_ip_patterns(self):
        """Test IP pattern analysis"""
        self.analyzer.load_logs()
        ip_stats = self.analyzer.analyze_ip_patterns()

        # Should have 4 unique IPs
        self.assertEqual(len(ip_stats), 4)

        # Check specific IP stats
        self.assertEqual(ip_stats['100.34.17.233']['requests'], 1)
        self.assertEqual(len(ip_stats['100.34.17.233']['unique_urls']), 1)

    def test_detect_bot_behavior(self):
        """Test bot detection logic"""
        self.analyzer.load_logs()
        ip_stats = self.analyzer.analyze_ip_patterns()
        bot_candidates = self.analyzer.detect_bot_behavior(ip_stats)

        # Should detect the Python-urllib user agent as suspicious
        suspicious_ips = [bot['ip'] for bot in bot_candidates]
        self.assertIn('192.168.1.1', suspicious_ips)

    def test_analyze_performance(self):
        """Test performance analysis"""
        self.analyzer.load_logs()
        performance = self.analyzer.analyze_performance()

        self.assertEqual(performance['total_requests'], 7)
        self.assertGreater(performance['avg_response_time'], 0)
        self.assertIsInstance(performance['top_urls'], list)

    def test_generate_report(self):
        """Test report generation"""
        self.analyzer.load_logs()
        report = self.analyzer.generate_report()

        self.assertIn('WEB TRAFFIC ANALYSIS REPORT', report)
        self.assertIn('PERFORMANCE METRICS', report)
        self.assertIn('Total Requests: 7', report)


if __name__ == '__main__':
    unittest.main()
