#!/bin/bash
echo "Setting up log analysis project..."

mkdir -p logs output
chmod +x log_analyzer.py

echo "Building Docker image..."
docker build -t log-analyzer .

echo "Setup complete!"
echo ""
echo "To run analysis:"
echo "1. Place your log file in ./logs/"
echo "2. Run: docker-compose up"
echo "3. Check results in ./output/"